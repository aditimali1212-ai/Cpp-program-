#include<stdio.h>
int main()
{
int a,b,c,sum;
printf("Enter any three numbers:\n");
scanf("%d %d %d", &a ,&b ,&c );
sum=a+b+c;
printf("sum=%d",sum);
return 0;
}



