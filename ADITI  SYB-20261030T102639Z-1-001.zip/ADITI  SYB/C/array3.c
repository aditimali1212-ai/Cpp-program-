#include<stdio.h>
int main()
{
int a[5],i,res=0;
printf("\nEnter any 5 numbers:");
for(i=0;i<5;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<5;i++)
{
res=res-a[i];
}
printf("res of array=%d",res);
return 0;
}

