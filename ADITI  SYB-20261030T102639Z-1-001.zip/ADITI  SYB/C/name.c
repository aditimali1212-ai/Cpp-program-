#include<stdio.h>
int main()
{
printf("Name of the Student: Aditi\n");
printf("RollNO:13\n");
printf("Class: SY CSE ,DIV:B\n");
return 0;
}
